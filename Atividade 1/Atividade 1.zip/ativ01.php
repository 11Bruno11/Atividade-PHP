<?php
    print "Use máscara!"
?>