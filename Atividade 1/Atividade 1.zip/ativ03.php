<?php
    print "Bruno Henrique";
    print "<br>";
    print "TII2001M-03";
    print "<br>";
    print "23/08/2021";
?>