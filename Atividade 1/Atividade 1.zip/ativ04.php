<?php
$nome = "Bruno Henrique";
$data = "02/02/2004";

print "Olá, me chamo $nome e nasci em $data.";
?>