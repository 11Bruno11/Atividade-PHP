<?php
$nome01 = "Bruno";
$idade01 = "17";
$nome02 = "Lucas";
$idade02 = "10";
$nome03 = "Roney";
$idade03 = "45";
$nome04 = "Karla";
$idade04 = "40";

$total = $idade01 + $idade02 + $idade03 + $idade04;

print "Minha familia e constituida por quatro integrantes, por mim $nome01, meu irmão $nome02, minha mãe $nome04 e por meu pai $nome03.";
print "<br>";
print "Juntando nossas idades da exatamente $total anos.";
?>